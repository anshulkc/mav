import { z } from "zod";
import {
  defineDAINService,
  ToolConfig,
} from "@dainprotocol/service-sdk";
import { CardUIBuilder, TableUIBuilder } from "@dainprotocol/utils";
import axios, { AxiosInstance } from 'axios';
import dotenv from 'dotenv';

dotenv.config();

const LINKD_API_KEY = process.env.LINKD_API_KEY;
if (!LINKD_API_KEY) {
  throw new Error("LINKD_API_KEY is not set in the .env file.");
}

// Define types based on the Linkd API response
interface Experience {
  title: string;
  company_name: string;
  start_date: string;
  end_date: string | null;
  description: string;
  location: string;
  company_logo: string;
}

interface Education {
  degree: string;
  field_of_study: string;
  school_name: string;
  start_date: string;
  end_date: string;
  description: string;
  school_logo: string;
}

interface Profile {
  id: string;
  name: string;
  location: string;
  headline: string;
  description: string;
  title: string;
  profile_picture_url: string;
  linkedin_url: string;
}

interface UserResult {
  profile: Profile;
  experience: Experience[];
  education: Education[];
}

interface SearchResponse {
  results: UserResult[];
  total: number;
  query: string;
  error: string | null;
}

interface SearchParams {
  query: string;
  limit?: number;
  school?: string[];
}

// Create axios instance
const api: AxiosInstance = axios.create({
  baseURL: 'https://search.linkd.inc/api',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${LINKD_API_KEY}`,
  },
});

// Function to search users
const searchUsers = async (params: SearchParams): Promise<SearchResponse> => {
  try {
    const { query, limit = 10, school } = params;
    
    const queryParams = new URLSearchParams();
    queryParams.append('query', query);
    
    if (limit) {
      queryParams.append('limit', limit.toString());
    }
    
    if (school && school.length > 0) {
      school.forEach(s => queryParams.append('school', s));
    }
    
    const response = await api.get<SearchResponse>(`/search/users?${queryParams.toString()}`);
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      if (error.response?.status === 401) {
        throw new Error("Invalid or expired API key");
      }
      if (error.response?.data) {
        const errorMessage = 
          error.response.data.error || 
          error.response.data.detail || 
          error.response.data.message || 
          JSON.stringify(error.response.data);
        throw new Error(errorMessage);
      }
    }
    throw new Error('Failed to perform search. Please check your connection and try again.');
  }
};

const getAlumniRecommendationsConfig: ToolConfig = {
  id: "get-alumni-recommendations",
  name: "Get Alumni Recommendations",
  description: "Recommends alumni connections based on shared interests and background",
  input: z.object({
    query: z.string().describe("Search query for alumni"),
    limit: z.number().optional().default(5).describe("Number of recommendations to return"),
    school: z.array(z.string()).optional().describe("List of schools to filter by"),
  }),
  output: z.object({
    recommendations: z.array(z.object({
      name: z.string(),
      title: z.string(),
      company: z.string(),
      location: z.string(),
      headline: z.string(),
      profileUrl: z.string(),
      imageUrl: z.string(),
    })),
  }),
  handler: async ({ query, limit, school }, agentInfo) => {
    try {
      const searchParams: SearchParams = { query, limit, school };
      const response = await searchUsers(searchParams);

      const recommendations = response.results.map(user => ({
        name: user.profile.name,
        title: user.profile.title,
        company: user.experience[0]?.company_name || 'N/A',
        location: user.profile.location,
        headline: user.profile.headline,
        profileUrl: user.profile.linkedin_url,
        imageUrl: user.profile.profile_picture_url,
      }));

      const tableUI = new TableUIBuilder()
        .addColumns([
          { key: "name", header: "Name", type: "text" },
          { key: "title", header: "Title", type: "text" },
          { key: "company", header: "Company", type: "text" },
          { key: "location", header: "Location", type: "text" },
          { key: "headline", header: "Headline", type: "text" },
          { key: "profileUrl", header: "Profile", type: "link" },
        ])
        .rows(recommendations.map(r => ({
          ...r,
          profileUrl: r.profileUrl ? { text: "View Profile", url: r.profileUrl } : "N/A",
        })))
        .build();

      const cardUI = new CardUIBuilder()
        .title("Alumni Recommendations")
        .addChild(tableUI)
        .build();

      return {
        text: `Here are ${recommendations.length} alumni recommendations based on your query: "${query}"`,
        data: { recommendations },
        ui: cardUI,
      };
    } catch (error: unknown) {
      console.error('Error fetching alumni recommendations:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      return {
        text: "Sorry, there was an error fetching alumni recommendations",
        data: { recommendations: [] },
        ui: new CardUIBuilder().title("Error").content(`Unable to fetch alumni recommendations: ${errorMessage}`).build(),
      };
    }
  },
};

const askAlumConfig: ToolConfig = {
  id: "ask-alum",
  name: "Ask an Alum",
  description: "Match students with relevant alumni for quick questions",
  input: z.object({
    question: z.string().describe("Student's question"),
    studentProfile: z.object({
      major: z.string(),
      graduationYear: z.number(),
      interests: z.array(z.string()),
    }).describe("Student's profile information"),
  }),
  output: z.object({
    matchedAlum: z.object({
      name: z.string(),
      title: z.string(),
      company: z.string(),
      profileUrl: z.string(),
    }),
    questionSent: z.boolean(),
  }),
  handler: async ({ question, studentProfile }, agentInfo) => {
    try {
      const searchQuery = `${studentProfile.major} ${studentProfile.interests.join(' ')}`;
      const searchParams = { query: searchQuery, limit: 1 };
      const response = await searchUsers(searchParams);

      if (response.results.length === 0) {
        throw new Error("No matching alumni found");
      }

      const matchedAlum = response.results[0];
      const alumnInfo = {
        name: matchedAlum.profile.name,
        title: matchedAlum.profile.title,
        company: matchedAlum.experience[0]?.company_name || 'N/A',
        profileUrl: matchedAlum.profile.linkedin_url,
      };

      // In a real-world scenario, you would send the question to the alum here
      const questionSent = true;

      const cardUI = new CardUIBuilder()
        .title("Matched Alum")
        .content(`Your question has been sent to ${alumnInfo.name}, ${alumnInfo.title} at ${alumnInfo.company}.`)
        .build();

      return {
        text: `Successfully matched with an alum and sent your question.`,
        data: { matchedAlum: alumnInfo, questionSent },
        ui: cardUI,
      };
    } catch (error: unknown) {
      console.error('Error in Ask an Alum:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      return {
        text: "Sorry, there was an error matching you with an alum",
        data: { matchedAlum: null, questionSent: false },
        ui: new CardUIBuilder().title("Error").content(`Unable to match with an alum: ${errorMessage}`).build(),
      };
    }
  },
};

const bruinLinkdConfig: ToolConfig = {
  id: "bruin-linkd",
  name: "BruinLinkd",
  description: "Connect two Bruins with shared interests",
  input: z.object({
    interests: z.array(z.string()).describe("Shared interests to match on"),
  }),
  output: z.object({
    matchedBruins: z.array(z.object({
      name: z.string(),
      interests: z.array(z.string()),
    })),
  }),
  handler: async ({ interests }, agentInfo) => {
    try {
      const searchQuery = interests.join(' ');
      const searchParams = { query: searchQuery, limit: 2, school: ['UCLA'] };
      const response = await searchUsers(searchParams);

      if (response.results.length < 2) {
        throw new Error("Not enough matching Bruins found");
      }

      const matchedBruins = response.results.slice(0, 2).map(bruin => ({
        name: bruin.profile.name,
        interests: interests,
      }));

      const cardUI = new CardUIBuilder()
        .title("BruinLinkd Match")
        .content(`Matched ${matchedBruins[0].name} with ${matchedBruins[1].name} based on shared interests: ${interests.join(', ')}`)
        .build();

      return {
        text: `Successfully matched two Bruins based on shared interests.`,
        data: { matchedBruins },
        ui: cardUI,
      };
    } catch (error: unknown) {
      console.error('Error in BruinLinkd:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
      return {
        text: "Sorry, there was an error matching Bruins",
        data: { matchedBruins: [] },
        ui: new CardUIBuilder().title("Error").content(`Unable to complete BruinLinkd: ${errorMessage}`).build(),
      };
    }
  },
};

const networkingService = defineDAINService({
  metadata: {
    title: "UCLA Networking Service",
    description: "A comprehensive service for alumni connections, mentorship, and networking opportunities",
    version: "1.0.0",
    author: "Your Name",
    tags: ["networking", "alumni", "connections", "mentorship", "UCLA"],
    capabilities: [
      "Get alumni recommendations based on specific search criteria",
      "Match students with relevant alumni for asking career questions",
      "Connect UCLA students (Bruins) with shared interests",
      "Provide detailed profiles of alumni including their current roles and companies",
      "Facilitate networking opportunities within the UCLA community"
    ]
  },
  identity: {
    apiKey: process.env.DAIN_API_KEY,
  },
  tools: [getAlumniRecommendationsConfig, askAlumConfig, bruinLinkdConfig],
});

networkingService.startNode().then(({ address }) => {
  console.log("UCLA Networking Service is running at :" + address().port);
});
